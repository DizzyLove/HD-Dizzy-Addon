# HDRE1HUD
A HUD reskin mod for Hideous Destructor

A HUD redesign inspired by Resident Evil 1's
inventory screen. Adds display panels for
the player mug, inventory items, and heart
tracker.

[WIP - May contain graphical errors]

Credits:

Original statusbar.zs code by MatthewTheGlutton

Inventory Screen assets by Capcom

Sprites ripped by Baddassbill 
from Spriter's Resource
