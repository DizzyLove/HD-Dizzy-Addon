# HOPPER
A mod for Hideous Destructor
------------------------------------------
Compatible with Hideous Destructor Release Version 4.8.2a
------------------------------------------
Massive thank you to FDA for all of your work with backblasts and fixing up weapon code! 
Seriously this would have been literal months before I would've had this ready for release were it not for your help.


        Loadout Code: hop
        Loadout Optional Code: hop heat (<- starts with heat round)

        The "HOPPER" Rocket Launcher - A single load Rocket Launcher capable of 
        launching either rocket grenades or HEAT rockets. Main positives are; incredibly 
        lightweight, ease of access to HEAT rockets, AND you can backpack it! Compliments 
        just about any loadout needing some heavy firepower. 

        This weapon can be found in single rocket ammo spawns, or more commonly in
        rocket crate spawns. Can be found pre-loaded with a rocket grenade, 
        HEAT round, or empty, with text signifying each.

        Be very mindful of walls however, as this is a tube launcher with backblast!
        Firing off rocket grenades will only get you mildly singed, but HEAT rounds
        WILL set you ablaze!
------------------------------------------
Additional lore in wep_hdhopper.zsc
